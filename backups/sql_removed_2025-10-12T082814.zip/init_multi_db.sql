-- init_multi_db.sql
-- Crea una base de datos por microservicio y sus tablas básicas.
-- Ejecutar con: psql -U admin -d postgres -f init_multi_db.sql

-- Crear bases si no existen (usando psql \gexec trick)
SELECT 'CREATE DATABASE users_db' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'users_db');\gexec
SELECT 'CREATE DATABASE reports_db' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'reports_db');\gexec
SELECT 'CREATE DATABASE alerts_db' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'alerts_db');\gexec
SELECT 'CREATE DATABASE notifications_db' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'notifications_db');\gexec
SELECT 'CREATE DATABASE preferences_db' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'preferences_db');\gexec
SELECT 'CREATE DATABASE logs_db' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'logs_db');\gexec

-- USERS DB
\connect users_db
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone varchar(20) UNIQUE NOT NULL,
  password_hash varchar NOT NULL,
  name varchar,
  location varchar,
  notifications_sms boolean DEFAULT true,
  notifications_telegram boolean DEFAULT false,
  notifications_email boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz
);

-- REPORTS DB
\connect reports_db
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  crop_type varchar NOT NULL,
  start_at timestamptz,
  end_at timestamptz,
  alerts_alto int DEFAULT 0,
  alerts_medio int DEFAULT 0,
  alerts_bajo int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz
);

CREATE TABLE IF NOT EXISTS temperature_points (
  id bigserial PRIMARY KEY,
  report_id uuid,
  ts timestamptz NOT NULL,
  temperature numeric(5,2) NOT NULL,
  has_alert boolean DEFAULT false,
  alert_severity smallint NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(report_id, ts)
);
CREATE INDEX IF NOT EXISTS idx_temperature_points_report_ts ON temperature_points(report_id, ts);

-- ALERTS DB
\connect alerts_db
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid,
  user_id uuid NOT NULL,
  ts timestamptz NOT NULL,
  type varchar NOT NULL,
  severity smallint NOT NULL,
  title varchar NOT NULL,
  description text,
  status varchar DEFAULT 'active',
  resolved_at timestamptz NULL,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_alerts_user_ts ON alerts(user_id, ts DESC);

-- NOTIFICATIONS DB
\connect notifications_db
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  platform varchar,
  token text,
  last_seen timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notification_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  channel varchar,
  status varchar,
  payload jsonb,
  sent_at timestamptz DEFAULT now()
);

-- PREFERENCES DB
\connect preferences_db
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id uuid,
  tipo_alerta varchar,
  activo boolean DEFAULT true,
  config jsonb,
  created_at timestamptz DEFAULT now()
);

-- LOGS DB
\connect logs_db
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS system_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fuente varchar,
  nivel varchar,
  mensaje text,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

\connect postgres

-- Fin del script
