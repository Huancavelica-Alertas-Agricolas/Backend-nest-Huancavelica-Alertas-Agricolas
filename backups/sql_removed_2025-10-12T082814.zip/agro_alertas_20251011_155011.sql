--
-- PostgreSQL database dump
--

\restrict rykvxZpUqfyRYVBywkZQoPjhHoksAziRJFuVue7QbNCgqAcP5XHdiTG2uaF3lR0

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: alert_canal_canal_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_canal_canal_enum AS ENUM (
    'email',
    'sms',
    'push',
    'webhook'
);


ALTER TYPE public.alert_canal_canal_enum OWNER TO admin;

--
-- Name: alert_canal_estado_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_canal_estado_enum AS ENUM (
    'pendiente',
    'enviado',
    'fallido',
    'entregado'
);


ALTER TYPE public.alert_canal_estado_enum OWNER TO admin;

--
-- Name: alertas_estado_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alertas_estado_enum AS ENUM (
    'activa',
    'enviada',
    'cancelada',
    'expirada'
);


ALTER TYPE public.alertas_estado_enum OWNER TO admin;

--
-- Name: alertas_tipo_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alertas_tipo_enum AS ENUM (
    'lluvia',
    'temperatura',
    'helada',
    'sequia',
    'viento'
);


ALTER TYPE public.alertas_tipo_enum OWNER TO admin;

--
-- Name: logs_status_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.logs_status_enum AS ENUM (
    'success',
    'error',
    'warning',
    'info'
);


ALTER TYPE public.logs_status_enum OWNER TO admin;

--
-- Name: logs_tipo_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.logs_tipo_enum AS ENUM (
    'alerta_creada',
    'alerta_enviada',
    'alerta_cancelada',
    'error_envio',
    'lectura_recibida',
    'sistema'
);


ALTER TYPE public.logs_tipo_enum OWNER TO admin;

--
-- Name: preferencias_notificacion_canal_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.preferencias_notificacion_canal_enum AS ENUM (
    'email',
    'sms',
    'push'
);


ALTER TYPE public.preferencias_notificacion_canal_enum OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alert_canal; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alert_canal (
    id integer NOT NULL,
    alerta_id integer NOT NULL,
    canal public.alert_canal_canal_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    "alertaId" integer,
    destinatario character varying NOT NULL,
    estado public.alert_canal_estado_enum DEFAULT 'pendiente'::public.alert_canal_estado_enum NOT NULL,
    fecha_envio timestamp without time zone,
    mensaje_error text,
    metadatos json
);


ALTER TABLE public.alert_canal OWNER TO admin;

--
-- Name: alert_canal_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.alert_canal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_canal_id_seq OWNER TO admin;

--
-- Name: alert_canal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.alert_canal_id_seq OWNED BY public.alert_canal.id;


--
-- Name: alertas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alertas (
    id integer NOT NULL,
    titulo character varying NOT NULL,
    mensaje text NOT NULL,
    tipo public.alertas_tipo_enum DEFAULT 'lluvia'::public.alertas_tipo_enum NOT NULL,
    estado public.alertas_estado_enum DEFAULT 'activa'::public.alertas_estado_enum NOT NULL,
    estacion_id integer NOT NULL,
    usuario_id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    fecha_expiracion timestamp without time zone,
    parametros json,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    "estacionId" integer,
    "usuarioId" integer
);


ALTER TABLE public.alertas OWNER TO admin;

--
-- Name: alertas_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.alertas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alertas_id_seq OWNER TO admin;

--
-- Name: alertas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.alertas_id_seq OWNED BY public.alertas.id;


--
-- Name: estaciones; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.estaciones (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    ubicacion character varying NOT NULL,
    latitud numeric(10,7),
    longitud numeric(10,7),
    activa boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.estaciones OWNER TO admin;

--
-- Name: estaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.estaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estaciones_id_seq OWNER TO admin;

--
-- Name: estaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.estaciones_id_seq OWNED BY public.estaciones.id;


--
-- Name: lecturas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.lecturas (
    id integer NOT NULL,
    estacion_id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    lluvia_mm numeric(5,2) NOT NULL,
    humedad numeric(5,2),
    presion numeric(6,2),
    velocidad_viento numeric(5,2),
    direccion_viento character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    "estacionId" integer,
    temp_max numeric(5,2) NOT NULL,
    temp_min numeric(5,2) NOT NULL
);


ALTER TABLE public.lecturas OWNER TO admin;

--
-- Name: lecturas_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.lecturas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lecturas_id_seq OWNER TO admin;

--
-- Name: lecturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.lecturas_id_seq OWNED BY public.lecturas.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    tipo public.logs_tipo_enum NOT NULL,
    status public.logs_status_enum DEFAULT 'info'::public.logs_status_enum NOT NULL,
    mensaje text NOT NULL,
    metadatos json,
    delivered_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    alerta_id integer,
    "usuarioId" integer,
    "alertaId" integer
);


ALTER TABLE public.logs OWNER TO admin;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO admin;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: preferencias_notificacion; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.preferencias_notificacion (
    id integer NOT NULL,
    canal public.preferencias_notificacion_canal_enum NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "usuarioId" integer,
    usuario_id integer NOT NULL,
    hora_inicio time without time zone,
    hora_fin time without time zone,
    dias_semana text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    configuracion character varying
);


ALTER TABLE public.preferencias_notificacion OWNER TO admin;

--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.preferencias_notificacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preferencias_notificacion_id_seq OWNER TO admin;

--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.preferencias_notificacion_id_seq OWNED BY public.preferencias_notificacion.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying NOT NULL,
    location character varying NOT NULL,
    description character varying
);


ALTER TABLE public.projects OWNER TO admin;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO admin;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    code character varying NOT NULL,
    nombre character varying NOT NULL,
    email character varying,
    telefono character varying,
    ciudad character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.usuarios OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: usuarios_projects_projects; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuarios_projects_projects (
    usuarios_id integer NOT NULL,
    projects_id integer NOT NULL
);


ALTER TABLE public.usuarios_projects_projects OWNER TO admin;

--
-- Name: alert_canal id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_canal ALTER COLUMN id SET DEFAULT nextval('public.alert_canal_id_seq'::regclass);


--
-- Name: alertas id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas ALTER COLUMN id SET DEFAULT nextval('public.alertas_id_seq'::regclass);


--
-- Name: estaciones id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.estaciones ALTER COLUMN id SET DEFAULT nextval('public.estaciones_id_seq'::regclass);


--
-- Name: lecturas id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas ALTER COLUMN id SET DEFAULT nextval('public.lecturas_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: preferencias_notificacion id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion ALTER COLUMN id SET DEFAULT nextval('public.preferencias_notificacion_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: alert_canal; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alert_canal (id, alerta_id, canal, created_at, "alertaId", destinatario, estado, fecha_envio, mensaje_error, metadatos) FROM stdin;
\.


--
-- Data for Name: alertas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alertas (id, titulo, mensaje, tipo, estado, estacion_id, usuario_id, "timestamp", fecha_expiracion, parametros, created_at, "estacionId", "usuarioId") FROM stdin;
\.


--
-- Data for Name: estaciones; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.estaciones (id, nombre, ubicacion, latitud, longitud, activa, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lecturas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.lecturas (id, estacion_id, "timestamp", lluvia_mm, humedad, presion, velocidad_viento, direccion_viento, created_at, "estacionId", temp_max, temp_min) FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.logs (id, usuario_id, tipo, status, mensaje, metadatos, delivered_at, created_at, alerta_id, "usuarioId", "alertaId") FROM stdin;
\.


--
-- Data for Name: preferencias_notificacion; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.preferencias_notificacion (id, canal, activo, "usuarioId", usuario_id, hora_inicio, hora_fin, dias_semana, created_at, updated_at, configuracion) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.projects (id, name, location, description) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuarios (id, code, nombre, email, telefono, ciudad, activo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: usuarios_projects_projects; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuarios_projects_projects (usuarios_id, projects_id) FROM stdin;
\.


--
-- Name: alert_canal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alert_canal_id_seq', 1, false);


--
-- Name: alertas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alertas_id_seq', 1, false);


--
-- Name: estaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.estaciones_id_seq', 1, false);


--
-- Name: lecturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.lecturas_id_seq', 1, false);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.logs_id_seq', 1, false);


--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.preferencias_notificacion_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, false);


--
-- Name: preferencias_notificacion PK_33b64ac87f77bcbf629d881978c; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion
    ADD CONSTRAINT "PK_33b64ac87f77bcbf629d881978c" PRIMARY KEY (id);


--
-- Name: projects PK_6271df0a7aed1d6c0691ce6ac50; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "PK_6271df0a7aed1d6c0691ce6ac50" PRIMARY KEY (id);


--
-- Name: usuarios_projects_projects PK_71a5b3d71810e88b8daaae66b49; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios_projects_projects
    ADD CONSTRAINT "PK_71a5b3d71810e88b8daaae66b49" PRIMARY KEY (usuarios_id, projects_id);


--
-- Name: lecturas PK_8843b4f95f8fd7fd75bd502bf49; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas
    ADD CONSTRAINT "PK_8843b4f95f8fd7fd75bd502bf49" PRIMARY KEY (id);


--
-- Name: alertas PK_b474c4021f8d6e4e13383ef1106; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT "PK_b474c4021f8d6e4e13383ef1106" PRIMARY KEY (id);


--
-- Name: alert_canal PK_c00912038061f91e8f5c615e505; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_canal
    ADD CONSTRAINT "PK_c00912038061f91e8f5c615e505" PRIMARY KEY (id);


--
-- Name: usuarios PK_d7281c63c176e152e4c531594a8; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT "PK_d7281c63c176e152e4c531594a8" PRIMARY KEY (id);


--
-- Name: logs PK_fb1b805f2f7795de79fa69340ba; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT "PK_fb1b805f2f7795de79fa69340ba" PRIMARY KEY (id);


--
-- Name: estaciones PK_fe18ed12cd95a6b4302a9bfe498; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.estaciones
    ADD CONSTRAINT "PK_fe18ed12cd95a6b4302a9bfe498" PRIMARY KEY (id);


--
-- Name: usuarios UQ_9bb842949691c6276e1c36d6148; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT "UQ_9bb842949691c6276e1c36d6148" UNIQUE (code);


--
-- Name: IDX_a2754630fcc342e56e6a5fbb30; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_a2754630fcc342e56e6a5fbb30" ON public.usuarios_projects_projects USING btree (usuarios_id);


--
-- Name: IDX_dea0c7c1739bb32585963d1908; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_dea0c7c1739bb32585963d1908" ON public.usuarios_projects_projects USING btree (projects_id);


--
-- Name: lecturas FK_0edcc18aceee52e1e92be560031; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas
    ADD CONSTRAINT "FK_0edcc18aceee52e1e92be560031" FOREIGN KEY ("estacionId") REFERENCES public.estaciones(id);


--
-- Name: preferencias_notificacion FK_2e4a8e6894bc5d88cac4cbde21b; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion
    ADD CONSTRAINT "FK_2e4a8e6894bc5d88cac4cbde21b" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id);


--
-- Name: alert_canal FK_4fe415bad3cc91d617b4a171378; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_canal
    ADD CONSTRAINT "FK_4fe415bad3cc91d617b4a171378" FOREIGN KEY ("alertaId") REFERENCES public.alertas(id);


--
-- Name: logs FK_72c6a8932efca20d5d8693e6619; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT "FK_72c6a8932efca20d5d8693e6619" FOREIGN KEY ("alertaId") REFERENCES public.alertas(id);


--
-- Name: usuarios_projects_projects FK_a2754630fcc342e56e6a5fbb307; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios_projects_projects
    ADD CONSTRAINT "FK_a2754630fcc342e56e6a5fbb307" FOREIGN KEY (usuarios_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: alertas FK_abe9e8672269d1aa3a73ded2339; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT "FK_abe9e8672269d1aa3a73ded2339" FOREIGN KEY ("estacionId") REFERENCES public.estaciones(id);


--
-- Name: logs FK_c50da38edd1feba47706acaa50b; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT "FK_c50da38edd1feba47706acaa50b" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id);


--
-- Name: usuarios_projects_projects FK_dea0c7c1739bb32585963d19085; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios_projects_projects
    ADD CONSTRAINT "FK_dea0c7c1739bb32585963d19085" FOREIGN KEY (projects_id) REFERENCES public.projects(id);


--
-- Name: alertas FK_df89995a5765a2884753707f1ed; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT "FK_df89995a5765a2884753707f1ed" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id);


--
-- PostgreSQL database dump complete
--

\unrestrict rykvxZpUqfyRYVBywkZQoPjhHoksAziRJFuVue7QbNCgqAcP5XHdiTG2uaF3lR0

