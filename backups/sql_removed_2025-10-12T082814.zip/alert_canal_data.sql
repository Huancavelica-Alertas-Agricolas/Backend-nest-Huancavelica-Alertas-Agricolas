--
-- PostgreSQL database dump
--

\restrict V40qh05nUdJGrrWDkaHg6rRZlaMdsHTqQP2D7qsts8eXBnGzr7tkoNG85MgnSOl

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: alert_canal; Type: TABLE DATA; Schema: public; Owner: admin
--



--
-- Name: alert_canal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alert_canal_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict V40qh05nUdJGrrWDkaHg6rRZlaMdsHTqQP2D7qsts8eXBnGzr7tkoNG85MgnSOl

