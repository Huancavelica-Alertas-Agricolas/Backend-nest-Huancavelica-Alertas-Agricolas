--
-- PostgreSQL database dump
--

\restrict WhdEGFF7fSIvYOJrrOjSVV8RLgWPOmbvyyHh5zEVKGqQPMOm5kVE3x2Nm7tZFn5

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: preferencias_notificacion; Type: TABLE DATA; Schema: public; Owner: admin
--



--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.preferencias_notificacion_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict WhdEGFF7fSIvYOJrrOjSVV8RLgWPOmbvyyHh5zEVKGqQPMOm5kVE3x2Nm7tZFn5

