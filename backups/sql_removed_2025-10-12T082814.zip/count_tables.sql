-- VACUUM y conteo por tabla en schema public
VACUUM ANALYZE;

CREATE TEMP TABLE tmp_counts(table_name text, rows bigint);

DO $$
DECLARE
  r record;
  cnt bigint;
BEGIN
  FOR r IN SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name LOOP
    EXECUTE format('SELECT count(*) FROM %I', r.table_name) INTO cnt;
    INSERT INTO tmp_counts VALUES (r.table_name, cnt);
  END LOOP;
END$$;

SELECT * FROM tmp_counts ORDER BY table_name;
