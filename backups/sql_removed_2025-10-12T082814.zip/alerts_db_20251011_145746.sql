--
-- PostgreSQL database dump
--

\restrict mXXpdv98ddFvCUP6yFKUof3mpBeBUApmRWol0tffE9jJ46n0HmmWjQPd1rYM6qA

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: alert_channels_channel_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_channels_channel_enum AS ENUM (
    'email',
    'sms',
    'push',
    'webhook'
);


ALTER TYPE public.alert_channels_channel_enum OWNER TO admin;

--
-- Name: alert_channels_status_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_channels_status_enum AS ENUM (
    'pendiente',
    'enviado',
    'fallido',
    'entregado'
);


ALTER TYPE public.alert_channels_status_enum OWNER TO admin;

--
-- Name: alerts_status_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alerts_status_enum AS ENUM (
    'activa',
    'enviada',
    'cancelada',
    'expirada'
);


ALTER TYPE public.alerts_status_enum OWNER TO admin;

--
-- Name: alerts_type_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alerts_type_enum AS ENUM (
    'lluvia',
    'temperatura',
    'helada',
    'sequia',
    'viento'
);


ALTER TYPE public.alerts_type_enum OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alert_channels; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alert_channels (
    id integer NOT NULL,
    "alertId" integer NOT NULL,
    channel public.alert_channels_channel_enum NOT NULL,
    recipient character varying NOT NULL,
    status public.alert_channels_status_enum DEFAULT 'pendiente'::public.alert_channels_status_enum NOT NULL,
    "sentAt" timestamp without time zone,
    "errorMessage" text,
    metadata json,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_channels OWNER TO admin;

--
-- Name: alert_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.alert_channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_channels_id_seq OWNER TO admin;

--
-- Name: alert_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.alert_channels_id_seq OWNED BY public.alert_channels.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    title character varying NOT NULL,
    description text NOT NULL,
    type public.alerts_type_enum DEFAULT 'lluvia'::public.alerts_type_enum NOT NULL,
    status public.alerts_status_enum DEFAULT 'activa'::public.alerts_status_enum NOT NULL,
    "stationId" integer NOT NULL,
    "userId" integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    "expiresAt" timestamp without time zone,
    params json,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alerts OWNER TO admin;

--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alerts_id_seq OWNER TO admin;

--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: alert_channels id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_channels ALTER COLUMN id SET DEFAULT nextval('public.alert_channels_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: alert_channels; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alert_channels (id, "alertId", channel, recipient, status, "sentAt", "errorMessage", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alerts (id, title, description, type, status, "stationId", "userId", "timestamp", "expiresAt", params, "createdAt") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1760210072998	InitSchemaAlertService1760210072998
\.


--
-- Name: alert_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alert_channels_id_seq', 1, false);


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alerts_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, true);


--
-- Name: alerts PK_60f895662df096bfcdfab7f4b96; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "PK_60f895662df096bfcdfab7f4b96" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: alert_channels PK_da89e9de0358309fb2ec1617e65; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_channels
    ADD CONSTRAINT "PK_da89e9de0358309fb2ec1617e65" PRIMARY KEY (id);


--
-- Name: alert_channels FK_1bc782dccfff6dc420232c84165; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_channels
    ADD CONSTRAINT "FK_1bc782dccfff6dc420232c84165" FOREIGN KEY ("alertId") REFERENCES public.alerts(id);


--
-- PostgreSQL database dump complete
--

\unrestrict mXXpdv98ddFvCUP6yFKUof3mpBeBUApmRWol0tffE9jJ46n0HmmWjQPd1rYM6qA

