-- Schema from api_examples.md
-- Safe creation: uses IF NOT EXISTS where possible

-- Enable pgcrypto for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1) users
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone varchar(20) UNIQUE NOT NULL,
  password_hash varchar NOT NULL,
  name varchar,
  location varchar,
  notifications_sms boolean DEFAULT true,
  notifications_telegram boolean DEFAULT false,
  notifications_email boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz
);

-- 2) reports
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  crop_type varchar NOT NULL,
  start_at timestamptz,
  end_at timestamptz,
  alerts_alto int DEFAULT 0,
  alerts_medio int DEFAULT 0,
  alerts_bajo int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz
);

-- 3) temperature_points
CREATE TABLE IF NOT EXISTS temperature_points (
  id bigserial PRIMARY KEY,
  report_id uuid REFERENCES reports(id) ON DELETE CASCADE,
  ts timestamptz NOT NULL,
  temperature numeric(5,2) NOT NULL,
  has_alert boolean DEFAULT false,
  alert_severity smallint NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(report_id, ts)
);
CREATE INDEX IF NOT EXISTS idx_temperature_points_report_ts ON temperature_points(report_id, ts);

-- 4) alerts
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid REFERENCES reports(id),
  user_id uuid REFERENCES users(id) NOT NULL,
  ts timestamptz NOT NULL,
  type varchar NOT NULL,
  severity smallint NOT NULL,
  title varchar NOT NULL,
  description text,
  status varchar DEFAULT 'active',
  resolved_at timestamptz NULL,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_alerts_user_ts ON alerts(user_id, ts DESC);

-- 5) user_crops
CREATE TABLE IF NOT EXISTS user_crops (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  crop_type varchar,
  area_ha numeric,
  location_geo varchar,
  planted_at date,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 6) recommendations
CREATE TABLE IF NOT EXISTS recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  title varchar,
  body text,
  severity smallint,
  related_crop_id uuid NULL,
  related_alert_id uuid NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- 7) devices
CREATE TABLE IF NOT EXISTS devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  platform varchar,
  token text,
  last_seen timestamptz DEFAULT now()
);

-- 8) notification_logs
CREATE TABLE IF NOT EXISTS notification_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  channel varchar,
  status varchar,
  payload jsonb,
  sent_at timestamptz DEFAULT now()
);

-- Optional: tidy up (no destructive operations)

-- End of file
