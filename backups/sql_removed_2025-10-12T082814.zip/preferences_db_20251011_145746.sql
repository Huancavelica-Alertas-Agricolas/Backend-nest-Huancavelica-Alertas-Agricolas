--
-- PostgreSQL database dump
--

\restrict xaJChey4pSK3RbK4NoGQ3KTTgzD05h27QBHKzb9Tc7doASNUnfajQ7PzMhXGbqo

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: preferencias_notificacion_canal_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.preferencias_notificacion_canal_enum AS ENUM (
    'email',
    'sms',
    'push',
    'whatsapp'
);


ALTER TYPE public.preferencias_notificacion_canal_enum OWNER TO admin;

--
-- Name: preferencias_notificacion_tipoalerta_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.preferencias_notificacion_tipoalerta_enum AS ENUM (
    'lluvia',
    'temperatura',
    'helada',
    'sequia',
    'viento',
    'todas'
);


ALTER TYPE public.preferencias_notificacion_tipoalerta_enum OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: preferencias_notificacion; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.preferencias_notificacion (
    id integer NOT NULL,
    "usuarioId" integer NOT NULL,
    canal public.preferencias_notificacion_canal_enum NOT NULL,
    "tipoAlerta" public.preferencias_notificacion_tipoalerta_enum DEFAULT 'todas'::public.preferencias_notificacion_tipoalerta_enum NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    destinatario character varying,
    configuracion json,
    "horaInicio" time without time zone,
    "horaFin" time without time zone,
    "diasSemana" text,
    "alertasInmediatas" boolean DEFAULT true NOT NULL,
    "resumenDiario" boolean DEFAULT false NOT NULL,
    "reporteSemanal" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.preferencias_notificacion OWNER TO admin;

--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.preferencias_notificacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preferencias_notificacion_id_seq OWNER TO admin;

--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.preferencias_notificacion_id_seq OWNED BY public.preferencias_notificacion.id;


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: preferencias_notificacion id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion ALTER COLUMN id SET DEFAULT nextval('public.preferencias_notificacion_id_seq'::regclass);


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1760210237253	InitSchemaPreferenceService1760210237253
\.


--
-- Data for Name: preferencias_notificacion; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.preferencias_notificacion (id, "usuarioId", canal, "tipoAlerta", activo, destinatario, configuracion, "horaInicio", "horaFin", "diasSemana", "alertasInmediatas", "resumenDiario", "reporteSemanal", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, true);


--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.preferencias_notificacion_id_seq', 1, false);


--
-- Name: preferencias_notificacion PK_33b64ac87f77bcbf629d881978c; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion
    ADD CONSTRAINT "PK_33b64ac87f77bcbf629d881978c" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict xaJChey4pSK3RbK4NoGQ3KTTgzD05h27QBHKzb9Tc7doASNUnfajQ7PzMhXGbqo

