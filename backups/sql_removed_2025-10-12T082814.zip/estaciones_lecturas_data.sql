--
-- PostgreSQL database dump
--

\restrict DxO8cBrwi6VHdEJlMWdPJiYX7IOQWRROede9l21ZfSue90br6N24WbcJYpWjYzW

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: estaciones; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.estaciones (id, nombre, ubicacion, latitud, longitud, activa, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lecturas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.lecturas (id, "estacionId", "timestamp", temp_max, temp_min, lluvia_mm, humedad, presion, estacion_id, velocidad_viento, direccion_viento, created_at) FROM stdin;
\.


--
-- Name: estaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.estaciones_id_seq', 1, false);


--
-- Name: lecturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.lecturas_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict DxO8cBrwi6VHdEJlMWdPJiYX7IOQWRROede9l21ZfSue90br6N24WbcJYpWjYzW

