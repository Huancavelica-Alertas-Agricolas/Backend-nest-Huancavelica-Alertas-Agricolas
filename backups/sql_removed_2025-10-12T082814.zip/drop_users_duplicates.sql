-- Script para revisar y (opcionalmente) dropear tablas duplicadas que pertenecen a otros servicios
-- Recomendación: hacer backup antes de ejecutar. Ejecutar en users_db.
-- Uso (PowerShell): docker exec -e PGPASSWORD=admin agro_postgres_users psql -U admin -d users_db -f /tmp/drop_users_duplicates.sql

BEGIN;

-- Tablas que no deberían pertenecer a users_db (DB-per-service):
DROP TABLE IF EXISTS alert_canal CASCADE;
DROP TABLE IF EXISTS alertas CASCADE;
DROP TABLE IF EXISTS logs CASCADE;
DROP TABLE IF EXISTS preferencias_notificacion CASCADE;

COMMIT;

-- Nota: revisar constraints y FK antes de ejecutar en producción.
