--
-- PostgreSQL database dump
--

\restrict I3433cKH3ugPlQBgKlsJ2LmsXgQvznAYAsRJdYz8AmQW8Ik5I1jeTSxyP34Jpe4

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS '';


--
-- Name: alert_canal_canal_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_canal_canal_enum AS ENUM (
    'email',
    'sms',
    'push',
    'webhook'
);


ALTER TYPE public.alert_canal_canal_enum OWNER TO admin;

--
-- Name: alert_canal_estado_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_canal_estado_enum AS ENUM (
    'pendiente',
    'enviado',
    'fallido',
    'entregado'
);


ALTER TYPE public.alert_canal_estado_enum OWNER TO admin;

--
-- Name: alertas_estado_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alertas_estado_enum AS ENUM (
    'activa',
    'enviada',
    'cancelada',
    'expirada'
);


ALTER TYPE public.alertas_estado_enum OWNER TO admin;

--
-- Name: alertas_tipo_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alertas_tipo_enum AS ENUM (
    'lluvia',
    'temperatura',
    'helada',
    'sequia',
    'viento'
);


ALTER TYPE public.alertas_tipo_enum OWNER TO admin;

--
-- Name: logs_status_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.logs_status_enum AS ENUM (
    'success',
    'error',
    'warning',
    'info'
);


ALTER TYPE public.logs_status_enum OWNER TO admin;

--
-- Name: logs_tipo_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.logs_tipo_enum AS ENUM (
    'alerta_creada',
    'alerta_enviada',
    'alerta_cancelada',
    'error_envio',
    'lectura_recibida',
    'sistema'
);


ALTER TYPE public.logs_tipo_enum OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: estaciones; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.estaciones (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    ubicacion character varying NOT NULL,
    latitud numeric(10,7),
    longitud numeric(10,7),
    activa boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.estaciones OWNER TO admin;

--
-- Name: estaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.estaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estaciones_id_seq OWNER TO admin;

--
-- Name: estaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.estaciones_id_seq OWNED BY public.estaciones.id;


--
-- Name: lecturas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.lecturas (
    id integer NOT NULL,
    "estacionId" integer,
    "timestamp" timestamp without time zone NOT NULL,
    temp_max numeric(5,2) NOT NULL,
    temp_min numeric(5,2) NOT NULL,
    lluvia_mm numeric(5,2) NOT NULL,
    humedad numeric(5,2),
    presion numeric(6,2),
    estacion_id integer NOT NULL,
    velocidad_viento numeric(5,2),
    direccion_viento character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lecturas OWNER TO admin;

--
-- Name: lecturas_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.lecturas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lecturas_id_seq OWNER TO admin;

--
-- Name: lecturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.lecturas_id_seq OWNED BY public.lecturas.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying NOT NULL,
    location character varying NOT NULL,
    description character varying
);


ALTER TABLE public.projects OWNER TO admin;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO admin;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    code character varying NOT NULL,
    nombre character varying NOT NULL,
    email character varying,
    telefono character varying,
    ciudad character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.usuarios OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: usuarios_projects_projects; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuarios_projects_projects (
    usuarios_id integer NOT NULL,
    projects_id integer NOT NULL
);


ALTER TABLE public.usuarios_projects_projects OWNER TO admin;

--
-- Name: estaciones id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.estaciones ALTER COLUMN id SET DEFAULT nextval('public.estaciones_id_seq'::regclass);


--
-- Name: lecturas id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas ALTER COLUMN id SET DEFAULT nextval('public.lecturas_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: estaciones; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.estaciones (id, nombre, ubicacion, latitud, longitud, activa, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lecturas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.lecturas (id, "estacionId", "timestamp", temp_max, temp_min, lluvia_mm, humedad, presion, estacion_id, velocidad_viento, direccion_viento, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1760210573276	InitSchemaUserService1760210573276
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.projects (id, name, location, description) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuarios (id, code, nombre, email, telefono, ciudad, activo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: usuarios_projects_projects; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuarios_projects_projects (usuarios_id, projects_id) FROM stdin;
\.


--
-- Name: estaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.estaciones_id_seq', 1, false);


--
-- Name: lecturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.lecturas_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, false);


--
-- Name: projects PK_6271df0a7aed1d6c0691ce6ac50; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "PK_6271df0a7aed1d6c0691ce6ac50" PRIMARY KEY (id);


--
-- Name: usuarios_projects_projects PK_71a5b3d71810e88b8daaae66b49; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios_projects_projects
    ADD CONSTRAINT "PK_71a5b3d71810e88b8daaae66b49" PRIMARY KEY (usuarios_id, projects_id);


--
-- Name: lecturas PK_8843b4f95f8fd7fd75bd502bf49; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas
    ADD CONSTRAINT "PK_8843b4f95f8fd7fd75bd502bf49" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: usuarios PK_d7281c63c176e152e4c531594a8; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT "PK_d7281c63c176e152e4c531594a8" PRIMARY KEY (id);


--
-- Name: estaciones PK_fe18ed12cd95a6b4302a9bfe498; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.estaciones
    ADD CONSTRAINT "PK_fe18ed12cd95a6b4302a9bfe498" PRIMARY KEY (id);


--
-- Name: usuarios UQ_9bb842949691c6276e1c36d6148; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT "UQ_9bb842949691c6276e1c36d6148" UNIQUE (code);


--
-- Name: IDX_a2754630fcc342e56e6a5fbb30; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_a2754630fcc342e56e6a5fbb30" ON public.usuarios_projects_projects USING btree (usuarios_id);


--
-- Name: IDX_dea0c7c1739bb32585963d1908; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_dea0c7c1739bb32585963d1908" ON public.usuarios_projects_projects USING btree (projects_id);


--
-- Name: lecturas FK_0edcc18aceee52e1e92be560031; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas
    ADD CONSTRAINT "FK_0edcc18aceee52e1e92be560031" FOREIGN KEY ("estacionId") REFERENCES public.estaciones(id);


--
-- Name: usuarios_projects_projects FK_a2754630fcc342e56e6a5fbb307; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios_projects_projects
    ADD CONSTRAINT "FK_a2754630fcc342e56e6a5fbb307" FOREIGN KEY (usuarios_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuarios_projects_projects FK_dea0c7c1739bb32585963d19085; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios_projects_projects
    ADD CONSTRAINT "FK_dea0c7c1739bb32585963d19085" FOREIGN KEY (projects_id) REFERENCES public.projects(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict I3433cKH3ugPlQBgKlsJ2LmsXgQvznAYAsRJdYz8AmQW8Ik5I1jeTSxyP34Jpe4

