--
-- PostgreSQL database dump
--

\restrict DbX7jxP5jVjcWrbYV28niRqSrpPceIn6YS45dg6uOKqwoNmvDx3AngoFaNpXxoG

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: alert_canal_canal_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_canal_canal_enum AS ENUM (
    'email',
    'sms',
    'push',
    'webhook'
);


ALTER TYPE public.alert_canal_canal_enum OWNER TO admin;

--
-- Name: alert_canal_estado_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alert_canal_estado_enum AS ENUM (
    'pendiente',
    'enviado',
    'fallido',
    'entregado'
);


ALTER TYPE public.alert_canal_estado_enum OWNER TO admin;

--
-- Name: alertas_estado_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alertas_estado_enum AS ENUM (
    'activa',
    'enviada',
    'cancelada',
    'expirada'
);


ALTER TYPE public.alertas_estado_enum OWNER TO admin;

--
-- Name: alertas_tipo_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.alertas_tipo_enum AS ENUM (
    'lluvia',
    'temperatura',
    'helada',
    'sequia',
    'viento'
);


ALTER TYPE public.alertas_tipo_enum OWNER TO admin;

--
-- Name: logs_status_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.logs_status_enum AS ENUM (
    'success',
    'error',
    'warning',
    'info'
);


ALTER TYPE public.logs_status_enum OWNER TO admin;

--
-- Name: logs_tipo_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.logs_tipo_enum AS ENUM (
    'alerta_creada',
    'alerta_enviada',
    'alerta_cancelada',
    'error_envio',
    'lectura_recibida',
    'sistema'
);


ALTER TYPE public.logs_tipo_enum OWNER TO admin;

--
-- Name: preferencias_notificacion_canal_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.preferencias_notificacion_canal_enum AS ENUM (
    'email',
    'sms',
    'push'
);


ALTER TYPE public.preferencias_notificacion_canal_enum OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alert_canal; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alert_canal (
    id integer NOT NULL,
    "alertaId" integer NOT NULL,
    canal public.alert_canal_canal_enum NOT NULL,
    destinatario character varying NOT NULL,
    estado public.alert_canal_estado_enum DEFAULT 'pendiente'::public.alert_canal_estado_enum NOT NULL,
    fecha_envio timestamp without time zone,
    mensaje_error text,
    metadatos json,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_canal OWNER TO admin;

--
-- Name: alert_canal_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.alert_canal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_canal_id_seq OWNER TO admin;

--
-- Name: alert_canal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.alert_canal_id_seq OWNED BY public.alert_canal.id;


--
-- Name: alertas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alertas (
    id integer NOT NULL,
    titulo character varying NOT NULL,
    mensaje text NOT NULL,
    tipo public.alertas_tipo_enum DEFAULT 'lluvia'::public.alertas_tipo_enum NOT NULL,
    estado public.alertas_estado_enum DEFAULT 'activa'::public.alertas_estado_enum NOT NULL,
    "estacionId" integer NOT NULL,
    "usuarioId" integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    "fechaExpiracion" timestamp without time zone,
    parametros json,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alertas OWNER TO admin;

--
-- Name: alertas_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.alertas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alertas_id_seq OWNER TO admin;

--
-- Name: alertas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.alertas_id_seq OWNED BY public.alertas.id;


--
-- Name: estaciones; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.estaciones (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    ubicacion character varying NOT NULL,
    latitud numeric(10,7),
    longitud numeric(10,7),
    activa boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.estaciones OWNER TO admin;

--
-- Name: estaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.estaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estaciones_id_seq OWNER TO admin;

--
-- Name: estaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.estaciones_id_seq OWNED BY public.estaciones.id;


--
-- Name: lecturas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.lecturas (
    id integer NOT NULL,
    "estacionId" integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    temp_max numeric(5,2) NOT NULL,
    temp_min numeric(5,2),
    lluvia_mm numeric(5,2) NOT NULL,
    humedad numeric(5,2),
    presion numeric(6,2),
    "velocidadViento" numeric(5,2),
    "direccionViento" character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lecturas OWNER TO admin;

--
-- Name: lecturas_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.lecturas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lecturas_id_seq OWNER TO admin;

--
-- Name: lecturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.lecturas_id_seq OWNED BY public.lecturas.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    "usuarioId" integer NOT NULL,
    "alertaCanalId" integer,
    tipo public.logs_tipo_enum NOT NULL,
    status public.logs_status_enum DEFAULT 'info'::public.logs_status_enum NOT NULL,
    mensaje text NOT NULL,
    metadatos json,
    "deliveredAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.logs OWNER TO admin;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO admin;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: preferencias_notificacion; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.preferencias_notificacion (
    id integer NOT NULL,
    "usuarioId" integer NOT NULL,
    canal public.preferencias_notificacion_canal_enum NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    configuracion character varying,
    "horaInicio" time without time zone,
    "horaFin" time without time zone,
    "diasSemana" text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.preferencias_notificacion OWNER TO admin;

--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.preferencias_notificacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preferencias_notificacion_id_seq OWNER TO admin;

--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.preferencias_notificacion_id_seq OWNED BY public.preferencias_notificacion.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    code character varying NOT NULL,
    nombre character varying NOT NULL,
    email character varying,
    telefono character varying,
    ciudad character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "ultimaAlertaId" integer,
    "ultimoLogId" integer,
    "preferenciasNotificacionSummary" character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.usuarios OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: alert_canal id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_canal ALTER COLUMN id SET DEFAULT nextval('public.alert_canal_id_seq'::regclass);


--
-- Name: alertas id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas ALTER COLUMN id SET DEFAULT nextval('public.alertas_id_seq'::regclass);


--
-- Name: estaciones id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.estaciones ALTER COLUMN id SET DEFAULT nextval('public.estaciones_id_seq'::regclass);


--
-- Name: lecturas id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas ALTER COLUMN id SET DEFAULT nextval('public.lecturas_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: preferencias_notificacion id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion ALTER COLUMN id SET DEFAULT nextval('public.preferencias_notificacion_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: alert_canal; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alert_canal (id, "alertaId", canal, destinatario, estado, fecha_envio, mensaje_error, metadatos, "createdAt") FROM stdin;
\.


--
-- Data for Name: alertas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alertas (id, titulo, mensaje, tipo, estado, "estacionId", "usuarioId", "timestamp", "fechaExpiracion", parametros, "createdAt") FROM stdin;
\.


--
-- Data for Name: estaciones; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.estaciones (id, nombre, ubicacion, latitud, longitud, activa, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lecturas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.lecturas (id, "estacionId", "timestamp", temp_max, temp_min, lluvia_mm, humedad, presion, "velocidadViento", "direccionViento", "createdAt") FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.logs (id, "usuarioId", "alertaCanalId", tipo, status, mensaje, metadatos, "deliveredAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1760210573276	InitSchemaUserService1760210573276
\.


--
-- Data for Name: preferencias_notificacion; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.preferencias_notificacion (id, "usuarioId", canal, activo, configuracion, "horaInicio", "horaFin", "diasSemana", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuarios (id, code, nombre, email, telefono, ciudad, activo, "ultimaAlertaId", "ultimoLogId", "preferenciasNotificacionSummary", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: alert_canal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alert_canal_id_seq', 1, false);


--
-- Name: alertas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.alertas_id_seq', 1, false);


--
-- Name: estaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.estaciones_id_seq', 1, false);


--
-- Name: lecturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.lecturas_id_seq', 1, false);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.logs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, true);


--
-- Name: preferencias_notificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.preferencias_notificacion_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, false);


--
-- Name: preferencias_notificacion PK_33b64ac87f77bcbf629d881978c; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion
    ADD CONSTRAINT "PK_33b64ac87f77bcbf629d881978c" PRIMARY KEY (id);


--
-- Name: lecturas PK_8843b4f95f8fd7fd75bd502bf49; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas
    ADD CONSTRAINT "PK_8843b4f95f8fd7fd75bd502bf49" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: alertas PK_b474c4021f8d6e4e13383ef1106; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT "PK_b474c4021f8d6e4e13383ef1106" PRIMARY KEY (id);


--
-- Name: alert_canal PK_c00912038061f91e8f5c615e505; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_canal
    ADD CONSTRAINT "PK_c00912038061f91e8f5c615e505" PRIMARY KEY (id);


--
-- Name: usuarios PK_d7281c63c176e152e4c531594a8; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT "PK_d7281c63c176e152e4c531594a8" PRIMARY KEY (id);


--
-- Name: logs PK_fb1b805f2f7795de79fa69340ba; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT "PK_fb1b805f2f7795de79fa69340ba" PRIMARY KEY (id);


--
-- Name: estaciones PK_fe18ed12cd95a6b4302a9bfe498; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.estaciones
    ADD CONSTRAINT "PK_fe18ed12cd95a6b4302a9bfe498" PRIMARY KEY (id);


--
-- Name: usuarios UQ_9bb842949691c6276e1c36d6148; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT "UQ_9bb842949691c6276e1c36d6148" UNIQUE (code);


--
-- Name: lecturas FK_0edcc18aceee52e1e92be560031; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lecturas
    ADD CONSTRAINT "FK_0edcc18aceee52e1e92be560031" FOREIGN KEY ("estacionId") REFERENCES public.estaciones(id);


--
-- Name: preferencias_notificacion FK_2e4a8e6894bc5d88cac4cbde21b; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.preferencias_notificacion
    ADD CONSTRAINT "FK_2e4a8e6894bc5d88cac4cbde21b" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id);


--
-- Name: alert_canal FK_4fe415bad3cc91d617b4a171378; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alert_canal
    ADD CONSTRAINT "FK_4fe415bad3cc91d617b4a171378" FOREIGN KEY ("alertaId") REFERENCES public.alertas(id);


--
-- Name: logs FK_aa69ed518248facf0dc399c9d72; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT "FK_aa69ed518248facf0dc399c9d72" FOREIGN KEY ("alertaCanalId") REFERENCES public.alert_canal(id);


--
-- Name: alertas FK_abe9e8672269d1aa3a73ded2339; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT "FK_abe9e8672269d1aa3a73ded2339" FOREIGN KEY ("estacionId") REFERENCES public.estaciones(id);


--
-- Name: logs FK_c50da38edd1feba47706acaa50b; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT "FK_c50da38edd1feba47706acaa50b" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id);


--
-- Name: alertas FK_df89995a5765a2884753707f1ed; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT "FK_df89995a5765a2884753707f1ed" FOREIGN KEY ("usuarioId") REFERENCES public.usuarios(id);


--
-- PostgreSQL database dump complete
--

\unrestrict DbX7jxP5jVjcWrbYV28niRqSrpPceIn6YS45dg6uOKqwoNmvDx3AngoFaNpXxoG

